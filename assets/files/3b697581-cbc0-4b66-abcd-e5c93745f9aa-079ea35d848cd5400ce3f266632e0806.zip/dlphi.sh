#!/bin/sh
mount -uw /net/mmx/fs/sda0/

[[ ! -e /net/mmx/fs/sda0/backup ]] && mkdir /net/mmx/fs/sda0/backup
cp /net/mmx/mnt/app/navigation/libPresentationController.so /net/mmx/fs/sda0/backup/
if [[ -e "/net/mmx/mnt/app/navigation" ]]; then
    cp /net/mmx/mnt/app/navigation/libPresentationController.so /net/mmx/fs/sda0/backup/
    if [[ -f "/net/mmx/fs/sda0/libPresentationController.so.patched" ]]; then
        mount -uw /net/mmx/mnt/app/

        rm /net/mmx/mnt/app/navigation/libPresentationController.so
        cp /net/mmx/fs/sda0/libPresentationController.so.patched /net/mmx/mnt/app/navigation/libPresentationController.so
        if [[ -f "/net/mmx/mnt/app/navigation/libPresentationController.so" ]]; then
            touch /net/mmx/fs/sda0/SUCCESS
            rm /net/mmx/fs/sda0/libPresentationController.so.patched
        else
            echo "Failed to transfer patched file to unit!" > /net/mmx/fs/sda0/ERROR.txt
        fi
    else
        echo "The patch file could not be located! Is the SD card in the correct slot? (Left)" > /net/mmx/fs/sda0/ERROR.txt
    fi
else
    echo "Your unit does not have navigation!" > /net/mmx/fs/sda0/ERROR.txt
fi

rm /net/mmx/fs/sda0/dlphi.sh ; sync ; /net/mmx/bin/slay SystemManager
